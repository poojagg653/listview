package com.example.sampleapp2;

import androidx.fragment.app.FragmentActivity;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends FragmentActivity {
GridView gridView;
String[] myTitle;
    String[] myDesc;

   int[] images={R.drawable.movie, R.drawable.movie, R.drawable.movie, R.drawable.movie,
            R.drawable.movie, R.drawable.movie, R.drawable.movie, R.drawable.movie, R.drawable.movie};
    String[] titles;
    GridView rails_single_row;

    RelativeLayout expand_collapse;
    ImageButton dots;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView=findViewById(R.id.grid);
        Resources resources=getResources();
       myTitle= resources.getStringArray(R.array.cast);
       myDesc=resources.getStringArray(R.array.castNames);

       MyAdapter adapter=new MyAdapter(this, myTitle, myDesc);
       gridView.setAdapter(adapter);

       rails_single_row=findViewById(R.id.second_grid);
       titles=resources.getStringArray(R.array.titles);
      CustomRailsAdapter railsAdapter=new CustomRailsAdapter(this, images, titles);
       rails_single_row.setAdapter(railsAdapter);
       int size=images.length;
       rails_single_row.setNumColumns(size);

       expand_collapse=findViewById(R.id.expand_Collapse);
       dots=findViewById(R.id.continuity);
       dots.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               if(expand_collapse.getVisibility()==v.VISIBLE)
               {
                   collapse(expand_collapse, 1000, 100);
                   expand_collapse.setVisibility(v.GONE);
               }
               else
               {
                   expand(expand_collapse, 1000, 280);
                   expand_collapse.setVisibility(v.VISIBLE);
               }
           }
       });

    }

    public static void expand(final View v, int duration, int targetHeight) {

        int prevHeight  = v.getHeight();

        v.setVisibility(View.VISIBLE);
        ValueAnimator valueAnimator = ValueAnimator.ofInt(prevHeight, targetHeight);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                v.getLayoutParams().height = (int) animation.getAnimatedValue();
                v.requestLayout();
            }
        });
        valueAnimator.setInterpolator(new DecelerateInterpolator());
        valueAnimator.setDuration(duration);
        valueAnimator.start();
    }


    public static void collapse(final View v, int duration, int targetHeight) {
        int prevHeight  = v.getHeight();
        ValueAnimator valueAnimator = ValueAnimator.ofInt(prevHeight, targetHeight);
        valueAnimator.setInterpolator(new DecelerateInterpolator());
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                v.getLayoutParams().height = (int) animation.getAnimatedValue();
                v.requestLayout();
            }
        });
        valueAnimator.setInterpolator(new DecelerateInterpolator());
        valueAnimator.setDuration(duration);
        valueAnimator.start();
    }
}


class MyAdapter extends ArrayAdapter<String> {

    Context c;
    String[] titleArray;
    String[] titleNamesArray;

    public MyAdapter(Context context, String[] titles, String[] desc) {
        super(context, R.layout.rails_row, R.id.first_title, titles);
        this.c = context;
        this.titleArray = titles;
        this.titleNamesArray=desc;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.single_rail, parent, false);
        TextView titles = view.findViewById(R.id.first_title);
        TextView names = view.findViewById(R.id.second_desc);
        titles.setText(titleArray[position]);
        names.setText(titleNamesArray[position]);
        return view;
    }
}





