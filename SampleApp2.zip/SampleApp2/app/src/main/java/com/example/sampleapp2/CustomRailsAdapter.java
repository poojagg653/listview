package com.example.sampleapp2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CustomRailsAdapter extends ArrayAdapter {
    Context context;
    int[] myImages;
    String[] myTitles;
    public CustomRailsAdapter(Context context, int[] imgs, String[] myTitle) {
        super(context, R.layout.rails_row, R.id.textView2, myTitle);
        this.context=context;
        this.myImages=imgs;
        this.myTitles=myTitle;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater= (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view=inflater.inflate(R.layout.rails_row, parent, false);
        ImageView imageView=view.findViewById(R.id.imageView);
        TextView textView=view.findViewById(R.id.textView2);
        imageView.setImageResource(myImages[position]);
        textView.setText(myTitles[position]);
        return view;
    }
}
